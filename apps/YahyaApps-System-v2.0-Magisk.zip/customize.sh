#!/sbin/sh
set_perm_recursive $MODPATH/system/priv-app 0 0 0755 0644
set_perm $MODPATH/system/priv-app/YahyaShield/YahyaShield.apk 0 0 0644
set_perm $MODPATH/system/priv-app/YahyaAccountHelp/YahyaAccountHelp.apk 0 0 0644
set_perm $MODPATH/system/priv-app/YahyaGamesTopup/YahyaGamesTopup.apk 0 0 0644
