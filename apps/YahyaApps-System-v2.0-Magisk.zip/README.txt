يحيى الحمزة - تطبيقات نظامية v2.0

التثبيت عبر Magisk:
1) ثبّت Magisk ثم افتح Magisk > Modules.
2) اختر Install from storage واختر ملف YahyaApps-System-v2.0-Magisk.zip.
3) انتظر اكتمال التثبيت ثم أعد التشغيل.
4) ستجد التطبيقات في:
   /system/priv-app/YahyaShield/YahyaShield.apk
   /system/priv-app/YahyaAccountHelp/YahyaAccountHelp.apk
   /system/priv-app/YahyaGamesTopup/YahyaGamesTopup.apk

التثبيت اليدوي في ROM نظامي أو مع root:
- انسخ كل ملف APK إلى المجلد المقابل في system/priv-app.
- اضبط صلاحية الملفات 0644 والمجلدات 0755.
- أعد التشغيل.

التحديث:
- للتحديث العادي ثبّت ملف APK أحدث بنفس التوقيع ورقم versionCode أعلى.
- لتحديث نسخة النظام استبدل ملفات APK داخل الموديول ثم أعد تثبيته.
- احتفظ بملفات keystore الموجودة في source/*/keystore/release.jks؛ تغييرها يمنع التحديث بنفس التوقيع.
